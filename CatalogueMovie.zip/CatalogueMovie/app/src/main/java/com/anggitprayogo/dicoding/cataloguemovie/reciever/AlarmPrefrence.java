package com.anggitprayogo.dicoding.cataloguemovie.reciever;

public class AlarmPrefrence {
}
