package com.anggitprayogo.dicoding.favouriteapp.network;

public class ServiceGenerator {

    public static final String BASE_URL_IMAGE = "http://image.tmdb.org/t/p/w185/";
    public static final String LANG = "en-US";
}
